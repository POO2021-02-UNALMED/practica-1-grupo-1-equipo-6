# Interfaz facturación
# Autor: Michael Moreno Valoyes
# Interfaz para definir el método de facturación
class Facturacion:
    def __init__(self):
        pass
    # Método facturar

    def facturar(self):
        pass
